import sys

sys.stdout.write('Hello from my script!\n')